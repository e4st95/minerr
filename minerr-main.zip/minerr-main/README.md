git init
git add your_file
git commit -m "first commit"
git remote add origin https://github.com/you_repository/you_project
git push -u origin master
